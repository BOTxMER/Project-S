namespace MicApp.DTOs
{
    public class UpdateMicDTO
    {
        public string? Model { get; set; }
        public string? Description { get; set; }
        public double? Price { get; set; }
    }
}
