namespace CarApp.DTOs
{
    public class CreateCarDTO
    {
        public string? Model { get; set; }
        public string? Description { get; set; }
        public double? Price { get; set; }
    }
}
