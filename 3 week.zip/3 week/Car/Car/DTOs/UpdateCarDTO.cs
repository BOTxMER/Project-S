namespace CarApp.DTOs
{
    public class UpdateCarDTO
    {
        public string? Model { get; set; }
        public string? Description { get; set; }
        public double? Price { get; set; }
    }
}
